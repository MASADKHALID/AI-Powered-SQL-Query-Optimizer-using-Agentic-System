# ============================================================
#  agent.py — Agentic AI SQL Assistant
#
#  This is the AGENTIC version of ai_agent.py
#
#  What makes it agentic:
#    - AI plans its own steps before writing SQL
#    - AI identifies which tables it needs automatically
#    - AI detects joins needed without being told
#    - AI validates its own SQL and fixes errors
#    - AI retries if first attempt fails
#    - AI breaks complex questions into sub-queries
#    - AI explains its own thinking step by step
#
#  Normal AI:   question → SQL (one shot)
#  Agentic AI:  question → think → plan → query → validate → fix → answer
#
#  Usage in main.py:
#    from agent import run_agent
#    result = run_agent(question, schema, db_type, execute_fn, model)
# ============================================================

import requests
import re
import json
import logging
from typing import Tuple, List, Dict, Any, Callable

logger = logging.getLogger(__name__)

# ── Ollama local API URL ──────────────────────────────────────
OLLAMA_URL = "http://localhost:11434/api/generate"

# ── Max times agent will retry if SQL fails ──────────────────
MAX_RETRIES = 3

# ── Max steps agent can take to answer one question ──────────
MAX_STEPS = 5


# ============================================================
#  HELPER: Call Ollama
#  Single function to call Ollama — used by all agent steps
# ============================================================

def call_ollama(prompt: str, model: str, temperature: float = 0.1, max_tokens: int = 500) -> str:
    """
    Send a prompt to Ollama and return the response text.
    Used internally by all agent functions.
    """
    try:
        response = requests.post(
            OLLAMA_URL,
            json={
                "model": model,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": temperature,
                    "top_p": 0.9,
                    "num_predict": max_tokens
                }
            },
            timeout=120  # agentic steps may need more time
        )
        response.raise_for_status()
        return response.json().get("response", "").strip()

    except requests.exceptions.ConnectionError:
        raise Exception("Cannot connect to Ollama. Run: ollama serve")
    except requests.exceptions.Timeout:
        raise Exception("Ollama timed out. Try a simpler question.")
    except Exception as e:
        raise Exception(f"Ollama error: {str(e)}")


# ============================================================
#  SCHEMA FORMATTER
#  Converts schema dict to readable text for AI prompts
# ============================================================

def schema_to_text(schema: dict) -> str:
    """Convert schema dict to text the AI can read."""
    lines = []
    tables = schema.get("tables", {})

    for table_name, table_info in tables.items():
        lines.append(f"Table: {table_name}")
        for col in table_info.get("columns", []):
            pk = " [PK]" if col["name"] in table_info.get("primary_key", []) else ""
            lines.append(f"  - {col['name']} ({col['type']}){pk}")
        for fk in table_info.get("foreign_keys", []):
            lines.append(f"  - FK: {fk['column']} → {fk['references_table']}.{fk['references_column']}")
        lines.append("")

    return "\n".join(lines)


# ============================================================
#  AGENT STEP 1 — UNDERSTAND THE QUESTION
#  Agent reads the question and identifies:
#    - What data the user wants
#    - Which tables are needed
#    - What kind of operation (count, list, compare, etc.)
# ============================================================

def step_understand(question: str, schema_text: str, model: str) -> Dict[str, Any]:
    """
    Agent understands the question before writing any SQL.
    Returns a plan with tables needed, operation type, complexity.
    """
    prompt = f"""You are a SQL planning expert. Analyze this question and the database schema.

DATABASE SCHEMA:
{schema_text}

USER QUESTION: {question}

Analyze and respond ONLY with a JSON object like this (no other text):
{{
  "tables_needed": ["table1", "table2"],
  "joins_needed": true or false,
  "operation": "SELECT/COUNT/SUM/AVG/GROUP/COMPARE",
  "complexity": "simple/medium/complex",
  "filters": ["any WHERE conditions needed"],
  "plan": "one sentence describing what SQL to write"
}}"""

    response = call_ollama(prompt, model, temperature=0.1, max_tokens=300)

    # Try to parse JSON response
    try:
        # Remove any markdown if present
        clean = response.replace("```json", "").replace("```", "").strip()
        return json.loads(clean)
    except Exception:
        # If JSON parsing fails — return basic plan
        logger.warning(f"Could not parse agent plan JSON: {response[:100]}")
        return {
            "tables_needed": list(schema_text.split("Table: "))[1:],
            "joins_needed": False,
            "operation": "SELECT",
            "complexity": "simple",
            "filters": [],
            "plan": f"Query database for: {question}"
        }


# ============================================================
#  AGENT STEP 2 — IDENTIFY JOINS
#  If multiple tables are needed, agent figures out exactly
#  how to join them using FK relationships in schema
# ============================================================

def step_identify_joins(tables_needed: List[str], schema: dict, db_type: str, model: str) -> str:
    """
    Given a list of tables, figure out the correct JOIN conditions.
    Returns a text description of joins to use.
    """
    if len(tables_needed) <= 1:
        return "No joins needed — single table query."

    # Build FK relationship map from schema
    fk_map = []
    for table_name, table_info in schema.get("tables", {}).items():
        for fk in table_info.get("foreign_keys", []):
            fk_map.append(
                f"{table_name}.{fk['column']} → {fk['references_table']}.{fk['references_column']}"
            )

    fk_text = "\n".join(fk_map) if fk_map else "No foreign keys defined"

    prompt = f"""Given these tables that need to be joined: {', '.join(tables_needed)}

Foreign key relationships in the database:
{fk_text}

Database type: {db_type.upper()}

Write ONLY the JOIN clauses needed to connect these tables correctly.
Example format:
INNER JOIN orders o ON c.id = o.customer_id
LEFT JOIN products p ON o.product_id = p.id

JOIN CLAUSES:"""

    return call_ollama(prompt, model, temperature=0.1, max_tokens=200)


# ============================================================
#  AGENT STEP 3 — GENERATE SQL
#  Now with the plan and join info, generate the actual SQL
# ============================================================

def step_generate_sql(
    question: str,
    schema_text: str,
    db_type: str,
    plan: Dict[str, Any],
    join_info: str,
    model: str,
    previous_error: str = None
) -> str:
    """
    Generate SQL using the plan from Step 1 and join info from Step 2.
    If previous_error is provided, agent tries to fix that error.
    """

    # Syntax rules for each database type
    if db_type.lower() == "mysql":
        syntax = "MySQL syntax. Backticks for identifiers. LIMIT for row limits."
    elif db_type.lower() == "mssql":
        syntax = "T-SQL syntax. Square brackets for identifiers. TOP instead of LIMIT."
    else:
        syntax = "Standard SQL syntax."

    # Add error context if retrying after failure
    error_context = ""
    if previous_error:
        error_context = f"""
PREVIOUS ATTEMPT FAILED WITH ERROR:
{previous_error}

Fix this error in your new SQL query.
"""

    prompt = f"""You are an expert SQL developer. Generate a SQL query based on this plan.

DATABASE TYPE: {db_type.upper()}
SYNTAX RULES: {syntax}

DATABASE SCHEMA:
{schema_text}

QUERY PLAN:
- Tables needed: {', '.join(plan.get('tables_needed', []))}
- Operation: {plan.get('operation', 'SELECT')}
- Complexity: {plan.get('complexity', 'simple')}
- Plan: {plan.get('plan', '')}

JOIN INFORMATION:
{join_info}
{error_context}

USER QUESTION: {question}

STRICT RULES:
1. Output ONLY the SQL query — no explanation, no markdown
2. Use exact table and column names from schema
3. Use table aliases (c for customers, o for orders etc.)
4. Add TOP 1000 (MSSQL) or LIMIT 1000 (MySQL) unless user wants all
5. Only SELECT queries — never DELETE, DROP, INSERT, UPDATE
6. If question cannot be answered write: -- Cannot answer: reason

SQL QUERY:"""

    raw = call_ollama(prompt, model, temperature=0.1, max_tokens=600)
    return clean_sql(raw)


# ============================================================
#  AGENT STEP 4 — VALIDATE SQL
#  Agent checks its own SQL for common mistakes before running
# ============================================================

def step_validate_sql(sql: str, schema: dict, db_type: str, model: str) -> Dict[str, Any]:
    """
    Agent validates its own generated SQL.
    Checks for: wrong table names, wrong column names, syntax errors.
    Returns: {"valid": True/False, "issues": ["issue1", "issue2"]}
    """

    # Get all valid table and column names from schema
    valid_tables = list(schema.get("tables", {}).keys())
    valid_columns = []
    for table_info in schema.get("tables", {}).values():
        for col in table_info.get("columns", []):
            valid_columns.append(col["name"])

    prompt = f"""You are a SQL validator. Check if this SQL query is correct.

DATABASE TYPE: {db_type.upper()}
VALID TABLE NAMES: {', '.join(valid_tables)}
VALID COLUMN NAMES: {', '.join(valid_columns[:30])}

SQL TO VALIDATE:
{sql}

Check for:
1. Table names that don't exist in valid tables list
2. Column names that don't exist
3. Syntax errors
4. Missing JOIN conditions
5. Dangerous operations (DELETE, DROP, etc.)

Respond ONLY with JSON (no other text):
{{
  "valid": true or false,
  "issues": ["issue1 if any", "issue2 if any"],
  "fixed_sql": "corrected SQL if issues found, empty string if valid"
}}"""

    response = call_ollama(prompt, model, temperature=0.1, max_tokens=400)

    try:
        clean = response.replace("```json", "").replace("```", "").strip()
        return json.loads(clean)
    except Exception:
        # If validation JSON fails — assume SQL is valid and proceed
        return {"valid": True, "issues": [], "fixed_sql": ""}


# ============================================================
#  AGENT STEP 5 — GENERATE EXPLANATION
#  After getting results, agent explains what it found
# ============================================================

def step_explain_results(
    question: str,
    sql: str,
    rows: List[Dict],
    row_count: int,
    thinking_steps: List[str],
    model: str
) -> str:
    """
    Agent explains the results in plain English.
    Shows what it found and summarizes the data.
    """
    # Build a sample of results for context
    sample = ""
    if rows:
        sample = f"First few rows: {json.dumps(rows[:3], default=str)}"

    prompt = f"""Explain these database query results in 1-2 clear sentences.
Be specific about what the data shows. Mention key numbers if relevant.

Original question: {question}
SQL executed: {sql}
Total rows returned: {row_count}
{sample}

Write a clear, helpful explanation (1-2 sentences max):"""

    explanation = call_ollama(prompt, model, temperature=0.3, max_tokens=150)

    # Keep it to 2 sentences max
    sentences = explanation.split(".")
    return ". ".join(sentences[:2]).strip() + "."


# ============================================================
#  MAIN AGENTIC FUNCTION
#  This is what main.py calls — runs all steps automatically
# ============================================================

def run_agent(
    question: str,
    schema: dict,
    db_type: str,
    execute_fn: Callable,   # function to run SQL on database — passed from main.py
    model: str = "sqlcoder"
) -> Dict[str, Any]:
    """
    Main agentic function — runs all steps automatically.

    Parameters:
      question   — user's plain English question
      schema     — database schema from database.py
      db_type    — "mysql" or "mssql"
      execute_fn — function that runs SQL and returns rows
                   signature: execute_fn(sql) -> {"rows": [...], "columns": [...]}
      model      — Ollama model name

    Returns:
      {
        "sql":          "final SQL query",
        "explanation":  "plain English explanation",
        "rows":         [...],
        "columns":      [...],
        "row_count":    5,
        "thinking":     ["step 1...", "step 2..."],  ← agent's thought process
        "retries":      0
      }
    """

    schema_text = schema_to_text(schema)
    thinking_steps = []   # tracks agent's reasoning — shown in frontend
    retries = 0
    last_error = None
    final_sql = ""
    rows = []
    columns = []

    logger.info(f"Agent starting for question: {question}")

    # ── AGENT STEP 1: Understand the question ─────────────────
    thinking_steps.append(f"🔍 Understanding question: '{question}'")
    logger.info("Agent Step 1: Understanding question...")

    plan = step_understand(question, schema_text, model)
    thinking_steps.append(
        f"📋 Plan: {plan.get('plan', 'Query the database')}"
    )
    thinking_steps.append(
        f"📊 Tables needed: {', '.join(plan.get('tables_needed', ['unknown']))}"
    )
    if plan.get("joins_needed"):
        thinking_steps.append("🔗 Joins required — will identify relationships")

    # ── AGENT STEP 2: Identify joins if needed ─────────────────
    join_info = "No joins needed."
    if plan.get("joins_needed") or len(plan.get("tables_needed", [])) > 1:
        thinking_steps.append("🔗 Identifying table relationships and JOIN conditions...")
        logger.info("Agent Step 2: Identifying joins...")
        join_info = step_identify_joins(
            plan.get("tables_needed", []),
            schema,
            db_type,
            model
        )
        thinking_steps.append(f"✓ Join strategy: {join_info[:100]}...")

    # ── AGENT STEPS 3-4: Generate SQL with retry loop ──────────
    # Agent tries up to MAX_RETRIES times to get working SQL
    for attempt in range(MAX_RETRIES):
        retries = attempt

        # Step 3: Generate SQL
        thinking_steps.append(
            f"⚡ Generating SQL (attempt {attempt + 1}/{MAX_RETRIES})..."
        )
        logger.info(f"Agent Step 3: Generating SQL attempt {attempt + 1}...")

        sql = step_generate_sql(
            question=question,
            schema_text=schema_text,
            db_type=db_type,
            plan=plan,
            join_info=join_info,
            model=model,
            previous_error=last_error  # pass previous error so agent can fix it
        )

        if not sql:
            thinking_steps.append("⚠ Could not generate SQL — retrying...")
            last_error = "Generated SQL was empty or invalid"
            continue

        thinking_steps.append(f"✓ SQL generated: {sql[:80]}...")

        # Step 4: Validate SQL
        thinking_steps.append("🔎 Validating SQL for errors...")
        logger.info("Agent Step 4: Validating SQL...")

        validation = step_validate_sql(sql, schema, db_type, model)

        if not validation.get("valid") and validation.get("fixed_sql"):
            # Agent found issues and auto-fixed them
            fixed = validation.get("fixed_sql", "")
            if fixed and fixed != sql:
                issues = ", ".join(validation.get("issues", []))
                thinking_steps.append(f"⚠ Issues found: {issues}")
                thinking_steps.append("🔧 Auto-fixing SQL...")
                sql = fixed
                thinking_steps.append(f"✓ Fixed SQL: {sql[:80]}...")

        # ── Try to execute the SQL on real database ───────────
        thinking_steps.append("🚀 Executing SQL on database...")
        logger.info(f"Agent executing SQL: {sql}")

        result = execute_fn(sql)

        if "error" in result:
            # SQL failed — agent will retry with error context
            last_error = result["error"]
            thinking_steps.append(f"❌ Execution failed: {last_error[:100]}")
            thinking_steps.append(f"🔄 Retrying with error context...")
            logger.warning(f"SQL execution failed: {last_error}")
            continue

        # ── Success! Got results ──────────────────────────────
        rows = result.get("rows", [])
        columns = result.get("columns", [])
        row_count = result.get("row_count", len(rows))
        final_sql = sql

        thinking_steps.append(f"✅ Success! Got {row_count} rows from database")
        logger.info(f"Agent succeeded with {row_count} rows")

        # Step 5: Explain results
        thinking_steps.append("💬 Generating explanation...")
        explanation = step_explain_results(
            question=question,
            sql=final_sql,
            rows=rows,
            row_count=row_count,
            thinking_steps=thinking_steps,
            model=model
        )

        return {
            "sql":         final_sql,
            "explanation": explanation,
            "rows":        rows,
            "columns":     columns,
            "row_count":   row_count,
            "thinking":    thinking_steps,
            "retries":     retries
        }

    # ── All retries failed ────────────────────────────────────
    thinking_steps.append(f"❌ All {MAX_RETRIES} attempts failed")
    raise Exception(
        f"Agent could not generate working SQL after {MAX_RETRIES} attempts. "
        f"Last error: {last_error}"
    )


# ============================================================
#  SQL CLEANER — same as ai_agent.py
# ============================================================

def clean_sql(raw: str) -> str:
    """Remove markdown and extra text from AI SQL output."""
    raw = re.sub(r"```sql\s*", "", raw, flags=re.IGNORECASE)
    raw = re.sub(r"```\s*", "", raw)

    lines = raw.strip().split("\n")
    sql_lines = []

    for line in lines:
        stripped = line.strip()
        if sql_lines and stripped and not stripped.startswith("--") and \
           not any(stripped.upper().startswith(kw) for kw in [
               "SELECT", "WITH", "FROM", "WHERE", "JOIN", "LEFT", "RIGHT",
               "INNER", "OUTER", "GROUP", "ORDER", "HAVING", "LIMIT",
               "TOP", "UNION", "--", ")", "AND", "OR", "ON", "AS", "CASE",
               "WHEN", "THEN", "ELSE", "END", "INNER", "CROSS"
           ]):
            if not any(c in stripped for c in ["(", ".", ",", "=", "<", ">", "'"]):
                break
        sql_lines.append(line)

    sql = "\n".join(sql_lines).strip().rstrip(";").strip()
    return sql if sql.upper().startswith(("SELECT", "WITH", "--")) else ""
